import React from 'react';
import axios from 'axios';
import Cell from './cell';
import blank_empty from './empty_board.png';
import blank_red from "./empty_red.png"; 
import blank_yellow from "./empty_yellow.png"; 
import red_empty from "./red_empty.png"; 
import red_red from "./red_red.png"; 
import red_yellow from "./red_yellow.png"; 
import yellow_empty from "./yellow_empty.png"; 
import yellow_red from "./yellow_red.png"; 
import yellow_yellow from "./yellow_yellow.png";

const changeCell = (value) => {
    const identifierMap = {
        0: blank_empty, 
        1: blank_red,
        2: blank_yellow, 
        3: red_empty, 
        4: red_red, 
        5: red_yellow, 
        6: yellow_empty, 
        7: yellow_red, 
        8: yellow_yellow
    }
    return identifierMap[value];
}

export default class Board extends React.Component {
    constructor() {
        super();
        var instance = axios.create({
            baseURL: 'https://da0995ba.ngrok.io',
            timeout: 10000
        })
        this.updateBoard = this.updateBoard.bind(this);
        this.state = {
            data: ['hi']
        }
        window.updateBoard = this.updateBoard.bind(this);
    }


    componentDidMount() {
        this.updateBoard('https://da0995ba.ngrok.io/board/1');
    }
    
    updateBoard(link) {
        axios({
            method: 'get', 
            url: link, 
            params: {
                ID: 'hsd'
            }
        })
        .then((function(response) {
            var data = response.data.data;
            for (var i = 0; i < data.length; i++) {
                for (var j = 0; j < data[i].length; j++) {
                    data[i][j] = changeCell(data[i][j]);
                }
            }
            console.log(response.data.data)
            this.setState((prevState) => {
            return {
                data: data
            }
        })
        
    })
    .bind(this)
    )}

   
    render() {
        if (this.state.data[0] == "hi") {
            return <div></div>;
        }
        return (
        <div>
            <table border="0" cellPadding="0" cellSpacing="0">
                <thead></thead>
                <tbody>
                    <tr><td><img src={this.state.data[0][0]}/></td><img src={this.state.data[0][1]}/><td><img src={this.state.data[0][2]}/></td><img src={this.state.data[0][3]}/><td><img src={this.state.data[0][4]}/></td><img src={this.state.data[0][5]}/><td><img src={this.state.data[0][6]}/></td></tr>
                    <tr><td><img src={this.state.data[1][0]}/></td><img src={this.state.data[1][1]}/><td><img src={this.state.data[1][2]}/></td><img src={this.state.data[1][3]}/><td><img src={this.state.data[1][4]}/></td><img src={this.state.data[1][5]}/><td><img src={this.state.data[1][6]}/></td></tr>
                    <tr><td><img src={this.state.data[2][0]}/></td><img src={this.state.data[2][1]}/><td><img src={this.state.data[2][2]}/></td><img src={this.state.data[2][3]}/><td><img src={this.state.data[2][4]}/></td><img src={this.state.data[2][5]}/><td><img src={this.state.data[2][6]}/></td></tr>
                    <tr><td><img src={this.state.data[3][0]}/></td><img src={this.state.data[3][1]}/><td><img src={this.state.data[3][2]}/></td><img src={this.state.data[3][3]}/><td><img src={this.state.data[3][4]}/></td><img src={this.state.data[3][5]}/><td><img src={this.state.data[3][6]}/></td></tr>
                    <tr><td><img src={this.state.data[4][0]}/></td><img src={this.state.data[4][1]}/><td><img src={this.state.data[4][2]}/></td><img src={this.state.data[4][3]}/><td><img src={this.state.data[4][4]}/></td><img src={this.state.data[4][5]}/><td><img src={this.state.data[4][6]}/></td></tr>
                    <tr><td><img src={this.state.data[5][0]}/></td><img src={this.state.data[5][1]}/><td><img src={this.state.data[5][2]}/></td><img src={this.state.data[5][3]}/><td><img src={this.state.data[5][4]}/></td><img src={this.state.data[5][5]}/><td><img src={this.state.data[5][6]}/></td></tr>
                </tbody>
            </table>
        </div>
        )
    }
}