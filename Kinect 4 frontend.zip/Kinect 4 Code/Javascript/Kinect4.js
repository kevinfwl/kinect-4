import React from 'react';
import Header from './Header';
import Board from './Board'; //can skip js if inside webpack
import PlayerTurn from './PlayerTurn';

class Kinect4 extends React.Component {

    render() {
        const subtitle = "Put your pride in the hands of a computer";
        return (
            <div>
                <Header subtitle ={subtitle} />
                <div className="container">
                    <PlayerTurn />
                    <Board/>
                </div>
            </div>
        );
    }
}

export default Kinect4;